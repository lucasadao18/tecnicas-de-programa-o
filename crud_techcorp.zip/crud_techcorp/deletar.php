<?php
include 'conexao.php';

// 1. Verifica se o ID do funcionário foi passado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    // Se o ID não for válido, redireciona de volta
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];

// 2. Query SQL para deletar o funcionário
// Graças ao ON DELETE CASCADE na Foreign Key, 
// todos os registros de pagamentos ligados a este funcionario_id 
// serão deletados automaticamente pela base de dados.
$sql = "DELETE FROM funcionarios WHERE id = ?";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Redireciona para a página principal com mensagem de sucesso
    header("Location: index.php?msg=sucesso_exclusao");
    exit();
} else {
    // Se houver um erro, exibe a mensagem
    echo "Erro ao excluir funcionário: " . $conexao->error;
}

$stmt->close();
$conexao->close();
?>