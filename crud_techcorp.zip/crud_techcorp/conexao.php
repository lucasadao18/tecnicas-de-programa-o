// conexao.php
<?php
// Configurações do seu MySQL
$host = 'localhost'; 
$usuario = 'root';   // Usuário padrão do XAMPP/WAMP
$senha = '';         // Senha padrão (geralmente vazia)
$banco = 'meu_crud'; 

// Cria a conexão
$conexao = new mysqli($host, $usuario, $senha, $banco);

// Verifica se houve erro na conexão
if ($conexao->connect_error) {
    // Interrompe o script e exibe o erro
    die("Falha na conexão com o banco de dados: " . $conexao->connect_error);
}

// Configura o charset para UTF8 (para acentuação)
$conexao->set_charset("utf8");

// A conexão está aberta e pronta para uso nas outras páginas.
?>